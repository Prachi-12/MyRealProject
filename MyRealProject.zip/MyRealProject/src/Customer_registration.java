

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Customer_registration")
public class Customer_registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Customer_registration() {
        super();
     
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{  
			boolean valid_user=false;
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/mydb","root","root");  
			String cnames=request.getParameter("cname1");
			String passs=request.getParameter("psw");
			int gen2=Integer.parseInt(request.getParameter("gen1"));
			String d=request.getParameter("dob");
			Date d1=sdf.parse(d);
			String cont=request.getParameter("contactno");
			String em=request.getParameter("email1");
			int cust=Integer.parseInt(request.getParameter("custid"));
			
			
		  PreparedStatement stmt=con.prepareStatement("insert into customer_info values(?,?,?,?,?,?,?) ");
          stmt.setString(1, cnames);
          stmt.setString(2, passs);
          stmt.setInt(3, gen2);
          stmt.setDate(4,  new java.sql.Date(d1.getTime()));
          stmt.setString(5, cont);
          stmt.setString(6, em);
          stmt.setInt(7, cust);
          stmt.executeUpdate();
		
		}catch(Exception e){ System.out.println(e);} 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}



