

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Mechanic_registration")
public class Mechanic_registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Mechanic_registration() {
        super();
    
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{  
			boolean valid_user=false;
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/mydb","root","root");  
			String mnames=request.getParameter("mechname");
			String passs1=request.getParameter("psw");
			String gen3=request.getParameter("gender");
			/*String d=request.getParameter("dob");
			Date d1=sdf.parse(d);*/
			String d=request.getParameter("dob");
			String cont=request.getParameter("cn");
			String em=request.getParameter("email");
			Double latitude=Double.parseDouble(request.getParameter("lat"));
			Double longitude=Double.parseDouble(request.getParameter("lon"));
			
			
		  PreparedStatement stmt=con.prepareStatement("insert into mechanic_info values(?,?,?,?,?,?,?,?) ");
          stmt.setString(1, mnames);
          stmt.setString(2, passs1);
          stmt.setString(3, gen3);
          /*stmt.setDate(4,  new java.sql.Date(d1.getTime()));*/
          stmt.setString(4, d);
          stmt.setString(5, cont);
          stmt.setString(6, em);
          stmt.setDouble(7, latitude);
          stmt.setDouble(8, longitude);
          stmt.executeUpdate();
		
          
          System.out.println("New mechanic user is created....");
          
		}catch(Exception e){ System.out.println(e);} 
	}
		
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
