

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginPage")
public class LoginData extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginData() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{  
			boolean valid_user=false;
			
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/mydb","root","root");  
      int user=Integer.parseInt(request.getParameter("user_id"));
      String pass=request.getParameter("pwd1");
     String type=request.getParameter("User");
     PreparedStatement stmt;
     if(type.equals("C"))
     {
       stmt=con.prepareStatement("select * from login_info where userId=? and password=? and Type=?"); 
          stmt.setInt(1, user);
          stmt.setString(2, pass);
          stmt.setString(3, type);
     }
     else
     {
    	 stmt=con.prepareStatement("select * from login_info where userId=? and password=? and Type=?"); 
         stmt.setInt(1, user);
         stmt.setString(2, pass);
         stmt.setString(3, type);
     }
          System.out.println("Data123 : " + user + " " + pass + " " + type);
          
			
			ResultSet rs=stmt.executeQuery();  
			while(rs.next())   
			{
				
				/*if (type == 'C')
					String nextJSP = "/CustomerDashbaord.jsp";
				else if (type == 'M')
					String nextJSP = "/MechanicDashbaord.jsp";
					*/
				
				System.out.println("Data in the loop " + rs.getString(1) + " "+rs.getString(2) + " "+rs.getString(3) + " ");
				
				String nextJSP = "/ValidUser.jsp";
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
				dispatcher.forward(request,response);
				
				
				System.out.println("Valid user..");
				valid_user=true;
			}
			
			System.out.println("Valid user"+valid_user);
			
			if (valid_user == false)
			{
				String nextJSP = "/InvalidUser.jsp";
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
				dispatcher.forward(request,response);
			}

				
			con.close();  
		}catch(Exception e){ System.out.println(e);}  
	}  

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
